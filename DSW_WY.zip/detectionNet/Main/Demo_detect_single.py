from Eval import detect

detect('case181_121.jpg')