from .detect_single import detect
